const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
const Car = require('./models/Car');
const bodyParser = require('body-parser');
const userRoute = require('./routes/User');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use(userRoute);


app.post('/cars', function (req, res) {
  console.log(req.body);
  Car.add(req.body);
  console.log(req, res);
});
app.delete('/cars', function (req, res) {
  console.log(req.body);
  Car.delete(req.body.id);
  res.send(req.body);
});
app.put('/cars', function (req, res) {
  console.log(req.body);
  Car.update(req.body);
  res.send(req.body);
});

app.listen(port, () => {
});

const pool = require('../db');
const Model = require('./Model');
console.log(Model);
class Car extends Model{
  constructor () {
    super('cars');
    this.id = `SERIAL PRIMARY KEY`;
    this.car_make = `VARCHAR(128) NOT NULL`;
    this.car_model = `VARCHAR(64)  NOT NULL`;
    this.date = `DATE NOT NULL`;
    this.user_id = `INT REFERENCES users (id)`;
  }



}

new Car().createSchema();
module.exports = new Car();

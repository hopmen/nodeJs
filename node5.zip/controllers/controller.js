/*
module.exports = class Controller {
  constructor (Model) {
    this.Model = Model;
  }

  static add (req, res) {
    this.Model.add(req.body, (err, result) => {
      if (err) {
        return console.error('Error executing query', err.stack);
        res.sendStatus(500);
      }
      res.sendStatus(200);
    });
  }
};*/



const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
const {Router} = require('express');
const User = require('./models/User');
const bodyParser = require('body-parser');
const router = Router();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.post('/new', function (req, res) {
  console.log(req.body);
  User.addUser(req.body);
  res.send(req.body);
});
app.delete('/new', function (req, res) {
  console.log(req.body);
  User.deleteUser(req.body.userId);
  res.send(req.body);
});
app.put('/new', function (req, res) {
  console.log(req.body);
  User.updateUser(req.body);
  res.send(req.body);
});
app.listen(port, () => {

  }
);

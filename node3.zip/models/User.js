const pool = require('../db');

class User {
  constructor () {
    this.id = `SERIAL PRIMARY KEY`;
    this.name = `VARCHAR(128) NOT NULL`;
    this.email = `VARCHAR(128) UNIQUE NOT NULL`;
    this.phone = `VARCHAR(64) UNIQUE NOT NULL`;
  }

  createSchema () {
    pool.query(`CREATE TABLE IF NOT EXISTS users (${Object.keys(this).map(i => `${i} ${this[i]}`).join(', ')});`,
      [],
      (err, result) => {
        if (err) {
          return console.error('Error executing query', err.stack);
        }
        console.log(`таблица 'users' создана`);
      })
  }

  addUser (user) {
    const textQuery = `
                INSERT INTO users(email, name, phone)
                VALUES ('${user.email}', '${user.name}', '${user.phone}');
      `;
    console.log(textQuery);
    pool.query(textQuery,
      [],
      (err, result) => {
        if (err) {
          return console.error('Error executing query', err.stack)
        }
        console.log(`Ифнормация добавлена`)
      });
  }

  deleteUser (userId) {
    const textQuery = `DELETE FROM users WHERE id=${userId}`;
    console.log(textQuery);
    pool.query(textQuery,
      [],
      (err, result) => {
        if (err) {
          return console.error('Error executing query', err.stack)
        }
        console.log(`Ифнормация удалена`)
      });
  }

  updateUser (user) {
    const textQuery = `UPDATE users SET ${
      Object.keys(user)
        .filter(i => i !== 'id')
        .map(i => `${i} = '${user[i]}'`)
        .join(',')} WHERE id = ${user.id};`;
    console.log(textQuery);
    pool.query(textQuery,
      [],
      (err, result) => {
        if (err) {
          return console.error('Error executing query', err.stack)
        }
        console.log(`Ифнормация изменена`)
      });
  }
}

new User().createSchema();
module.exports = new User();

const client = require('../db');

class Car {
  constructor () {
    this.id = `SERIAL PRIMARY KEY`;
    this.car_make = `VARCHAR(128) NOT NULL`;
    this.car_model = `VARCHAR(64)  NOT NULL`;
    this.date = `DATE NOT NULL`;
    this.user_id = `INT`;
  }

  createSchema () {
    client.connect()
      .then(() => client.query(`CREATE TABLE IF NOT EXISTS cars (${Object.keys(this).map(i => `${i} ${this[i]}`).join(', ')});`))
      .catch(e => console.error(e.stack))
      .finally(() => client.end());
  }

}

new Car().createSchema();
module.exports = new Car();
